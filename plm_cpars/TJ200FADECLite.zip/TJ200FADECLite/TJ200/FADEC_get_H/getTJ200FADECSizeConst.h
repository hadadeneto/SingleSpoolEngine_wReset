#ifndef GETTJ200FADECSIZECONST_H
#define GETTJ200FADECSIZECONST_H

/* FUNCTION FOR LOADING SIZE CONSTANTS USED IN FADEC AND MODEL CODES */

void getTJ200FADECSizeConst(int *Alt_Elem, int *MN_Elem, int *Fn_Elem, int *AS_Elem, int *SteadyOp_Elem, 
     int *PowerMan_Elem, int *NcHPCMap_Elem, int *WcHPCMap_Elem, int *Wc_per_Nc_HPC);

#endif