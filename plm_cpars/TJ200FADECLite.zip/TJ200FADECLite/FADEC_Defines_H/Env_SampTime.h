#ifndef ENV_SAMPTIME_H
#define ENV_SAMPTIME_H

/*	
% *************************************************************************
% written by Antonio Hadade Neto
% Turbomachine, São José dos Campos, SP
% February 3rd, 2020
%
% *************************************************************************/

/*-----------------------*/
/* ENVIRONMENT CONSTANTS */
/*-----------------------*/

/* Environment Constants */
#define TSTD					288.15
#define PSTD					101325
#define GAMMA_AIR               1.4

/*-----------------*/
/* SAMPLING PERIOD */
/*-----------------*/

/* Sampling period in milisecons*/
#define TICK					200

/*  Defines dummy element */
#define DUMMY_ELEM				1


#endif  /* ENV_SAMPTIME_H */

